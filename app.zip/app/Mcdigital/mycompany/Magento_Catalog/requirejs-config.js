var config = {
    map: {
        '*': {
            jqueryfancybox: 'Magento_Catalog/js/jquery-fancybox-min',
            jqueryslick: 'Magento_Catalog/js/slick.min'
        }
    },
    "shim": {
        "jqueryfancybox":
        {
            deps: ['jquery']
        }
    },


};
